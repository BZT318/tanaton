package com.example.finalproject_tanaton

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
