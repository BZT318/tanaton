import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:typed_data';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_database/firebase_database.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'auth.dart';
import 'home_page.dart';

class ProfileSetup extends StatefulWidget {
  static const String routeName = '/profile';
  final Map<String, dynamic>? userData;
  ProfileSetup({this.userData});

  @override
  State<ProfileSetup> createState() => _ProfileSetupState();
}

class _ProfileSetupState extends State<ProfileSetup> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _firstName = TextEditingController();
  final TextEditingController _lastName = TextEditingController();
  final TextEditingController _username = TextEditingController();
  final TextEditingController _phoneNumber = TextEditingController();
  final TextEditingController _birthDateController = TextEditingController();

  final List<String> prefix = ['นาย', 'นาง', 'นางสาว'];
  String? _selectedPrefix;
  DateTime? birthdayDate;

  final ImagePicker _picker = ImagePicker();
  XFile? _profileImage;
  String? _profileImageUrl;

  final DatabaseReference _dbRef = FirebaseDatabase.instance.ref();

  @override
  void initState() {
    super.initState();
    if (widget.userData != null) {
      _selectedPrefix = widget.userData?['prefix'] ?? '';
      _firstName.text = widget.userData?['firstName'] ?? '';
      _lastName.text = widget.userData?['lastName'] ?? '';
      _username.text = widget.userData?['username'] ?? '';
      _phoneNumber.text = widget.userData?['phoneNumber'] ?? '';
      _profileImageUrl = widget.userData?['profileImage'];
      if (widget.userData?['birthDate'] != null) {
        birthdayDate = DateTime.parse(widget.userData!['birthDate']);
        _birthDateController.text = "${birthdayDate!.day}/${birthdayDate!.month}/${birthdayDate!.year}";
      }
    }
  }

  Future<void> pickDate(BuildContext context) async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: birthdayDate ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );
    if (pickedDate != null) {
      setState(() {
        birthdayDate = pickedDate;
        _birthDateController.text = "${pickedDate.day}/${pickedDate.month}/${pickedDate.year}";
      });
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final pickedFile = await _picker.pickImage(source: source);
      if (pickedFile != null) {
        setState(() {
          _profileImage = pickedFile;
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error picking image: $e')),
      );
    }
  }

  Future<void> _uploadProfile(String uid) async {
    try {
      String? downloadUrl;
      if (_profileImage != null) {
        final storageRef = FirebaseStorage.instance.ref().child('profile/$uid.jpg');
        if (kIsWeb) {
          await storageRef.putData(await _profileImage!.readAsBytes());
        } else {
          await storageRef.putFile(File(_profileImage!.path));
        }
        downloadUrl = await storageRef.getDownloadURL();
      } else {
        downloadUrl = _profileImageUrl;
      }
      await _dbRef.child('users/$uid').set({
        'prefix': _selectedPrefix ?? '',
        'firstName': _firstName.text.trim(),
        'lastName': _lastName.text.trim(),
        'username': _username.text.trim(),
        'phoneNumber': _phoneNumber.text.trim(),
        'birthDate': birthdayDate?.toIso8601String() ?? '',
        'profileImage': downloadUrl ?? '',
        'profileComplete': true,
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error uploading profile: $e')),
      );
    }
  }

  void _submitForm() async {
    final user = AuthService().currentUser;
    if (_formKey.currentState!.validate() && user != null) {
      await _uploadProfile(user.uid);
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomePage()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('ตั้งค่าข้อมูลส่วนตัว')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                GestureDetector(
                  onTap: () => _pickImage(ImageSource.gallery),
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: _profileImage != null
                        ? FileImage(File(_profileImage!.path))
                        : (_profileImageUrl != null
                            ? NetworkImage(_profileImageUrl!) as ImageProvider
                            : AssetImage('assets/profile_placeholder.png')),
                  ),
                ),
                SizedBox(height: 20),
                DropdownButtonFormField(
                  value: _selectedPrefix,
                  items: prefix.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                  onChanged: (value) => setState(() => _selectedPrefix = value),
                  decoration: InputDecoration(labelText: 'คำนำหน้า'),
                ),
                TextFormField(controller: _firstName, decoration: InputDecoration(labelText: 'ชื่อ')),                
                TextFormField(controller: _lastName, decoration: InputDecoration(labelText: 'นามสกุล')),
                TextFormField(controller: _username, decoration: InputDecoration(labelText: 'ชื่อผู้ใช้')),
                TextFormField(controller: _phoneNumber, decoration: InputDecoration(labelText: 'เบอร์โทรศัพท์')),
                TextFormField(
                  controller: _birthDateController,
                  readOnly: true,
                  decoration: InputDecoration(suffixIcon: Icon(Icons.calendar_today)),
                  onTap: () => pickDate(context),
                ),
                SizedBox(height: 20),
                ElevatedButton(onPressed: _submitForm, child: Text('บันทึก')),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
